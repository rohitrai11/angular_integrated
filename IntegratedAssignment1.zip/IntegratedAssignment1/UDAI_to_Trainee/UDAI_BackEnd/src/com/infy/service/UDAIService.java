package com.infy.service;

import com.infy.model.AadharCard;

public interface UDAIService {

	public AadharCard getAadhar(String aadharNumber) throws Exception;

	public AadharCard updatePhoneNumber(AadharCard aadhar) throws Exception;
	
}
