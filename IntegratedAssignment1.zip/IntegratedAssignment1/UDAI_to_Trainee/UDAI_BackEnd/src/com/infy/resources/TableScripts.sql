DROP TABLE AadharCard;


create table AadharCard (
aadharNumber number(12) PRIMARY KEY,
name varchar2(30) not null,
dateOfBirth date not null,
address varchar2(50) not null,
phoneNumber number(10) not null
);

insert into AADHARCARD values(123456789012, 'Nidhi', '12-Jan-1993', 'Mysore', 1234567890)