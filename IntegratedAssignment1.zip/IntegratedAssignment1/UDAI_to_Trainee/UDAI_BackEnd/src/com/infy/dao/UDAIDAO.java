package com.infy.dao;

import com.infy.model.AadharCard;




public interface UDAIDAO {
	
	public AadharCard getAadhar(String aadharNumber);

	public AadharCard updatePhoneNumber(AadharCard aadhar);
	
}
