package com.infy.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.AadharCardEntity;
import com.infy.model.AadharCard;


@Repository("dao")
public class UDAIDAOImpl implements UDAIDAO {

	@Autowired
	SessionFactory sessionFactory;

	@Override
	public AadharCard getAadhar(String aadharNumber) {
		
		Session session = sessionFactory.getCurrentSession();
		AadharCardEntity aadharCardEntity = session.get(AadharCardEntity.class, aadharNumber);
		if(	aadharCardEntity !=null) {
			AadharCard aadharCard = new AadharCard();
			aadharCard.setAadharNumber(aadharCardEntity.getAadharNumber());
			aadharCard.setAddress(aadharCardEntity.getAddress());
			aadharCard.setDateOfBirth(aadharCardEntity.getDateOfBirth());
			aadharCard.setName(aadharCardEntity.getName());
			aadharCard.setPhoneNumber(aadharCardEntity.getPhoneNumber());
			return aadharCard;
		}
		return null;
		
	}

	@Override
	public AadharCard updatePhoneNumber(AadharCard aadhar) {
		Session session = sessionFactory.getCurrentSession();
		AadharCardEntity aadharCardEntity = session.get(AadharCardEntity.class, aadhar.getAadharNumber());
		if(	aadharCardEntity !=null) {
			aadharCardEntity.setPhoneNumber(aadhar.getPhoneNumber());
			return aadhar;
		}
		return null;
	}

	
}
