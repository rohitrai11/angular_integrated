package com.infy.api;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.model.AadharCard;
import com.infy.service.UDAIService;
import com.infy.service.UDAIServiceImpl;
import com.infy.utility.ContextFactory;



public class AadharAPI {
	
	private UDAIService service;
	
	public ResponseEntity<AadharCard> getAadhar(AadharCard aadhar){
		return null;
	}
	
	public ResponseEntity<AadharCard> updatePhoneNumber(AadharCard aadhar){
		return null;
	}


}
