export class AadharCard {
    aadharNumber: string;
    name: string;
	dateOfBirth: Date;
	address: string;
	phoneNumber: string;
	message: string;
}