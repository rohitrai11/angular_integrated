import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { AadharCard } from './aadhar-card';

@Injectable()
export class AadharCardService {

  constructor() { }

  getAadhar(data) : Promise<AadharCard> {
    return null
  }

  updatePhoneNumber(data): Promise<AadharCard> {
    return null
  }
  errorHandler(error){
    return Promise.reject(error.json())
  }

}
