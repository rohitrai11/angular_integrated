import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'aadharNumber'
})
export class AadharNumberPipe implements PipeTransform {

  transform(value: string, args?: any): any {
    
  }

}
