import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
import { AadharCardService } from './aadhar-card.service';
import { PhoneNumberValidator } from './phone-number.validator';

@Component({
  selector: 'app-aadhar-card',
  templateUrl: './aadhar-card.component.html',
  styleUrls: ['./aadhar-card.component.css']
})
export class AadharCardComponent implements OnInit {
  
  constructor() { }

  ngOnInit() {
  }

  getAadhar() {
  }
  updatePhoneNumber(){
  }
}
