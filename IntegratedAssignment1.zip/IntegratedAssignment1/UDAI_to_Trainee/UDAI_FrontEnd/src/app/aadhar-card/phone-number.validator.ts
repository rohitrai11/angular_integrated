import { AbstractControl } from "@angular/forms";

export class PhoneNumberValidator {
    static noRepeat(control: AbstractControl){
        
    }
}