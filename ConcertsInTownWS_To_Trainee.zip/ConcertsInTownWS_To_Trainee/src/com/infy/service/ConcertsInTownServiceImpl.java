package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.ConcertsInTownDAO;
import com.infy.model.ConcertBooking;

@Service("concertsInTownService")
@Transactional(readOnly = true)
public class ConcertsInTownServiceImpl implements ConcertsInTownService {

	@Autowired
	private ConcertsInTownDAO dao;

	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public ConcertBooking bookConcert(ConcertBooking concertBooking) throws Exception {
		ConcertBooking bookedConcertDetails = null;
		String amountAndId = dao.getAmountAndConcertIdOfConcertByGenreAndLocationAndDate(concertBooking);
      try{
		if (amountAndId!=null) {
			Double amount = Double.parseDouble(amountAndId.split("-")[0]);
			concertBooking.setConcertId(amountAndId.split("-")[1]);
			Double totalAmount = (concertBooking.getNoOfTicket() * amount);
			concertBooking.setTotalAmount(totalAmount);
			bookedConcertDetails = dao.bookConcert(concertBooking);
		}

		else {
			throw new Exception("CONCERTSINTOWNSERVICE.CONCERT_NOT_AVAILABLE_FOR_GIVEN_DETAILS");
		}
      }catch(Exception e){
    	  System.out.println("Hi Hello"+e);
    	  e.printStackTrace();
    	  throw e;
      }

		return bookedConcertDetails;

	}

}
