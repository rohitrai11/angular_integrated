package com.infy.api;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.model.ConcertBooking;
import com.infy.service.ConcertsInTownService;
import com.infy.service.ConcertsInTownServiceImpl;
import com.infy.utility.ContextFactory;

@RestController
@CrossOrigin
@RequestMapping(value="Concert")
public class ConcertAPI {
	private ConcertsInTownService concertTownService;
	@RequestMapping(method=RequestMethod.POST, value="booking")
	public ResponseEntity<ConcertBooking> bookConcert(@RequestBody ConcertBooking concertBooking) throws Exception {
		Environment environment= ContextFactory.getContext().getEnvironment();
		ResponseEntity<ConcertBooking> responseEntity=null;
		ConcertBooking returnedConcertBooking = new ConcertBooking();
		concertTownService = (ConcertsInTownService) ContextFactory.getContext().getBean(ConcertsInTownServiceImpl.class);
		try {
			System.out.println(concertBooking.getDateOfConcert()+" "+concertBooking.getLocation());
			
			returnedConcertBooking=concertTownService.bookConcert(concertBooking);
			returnedConcertBooking.setMessage(getBookingSuccessMessage(returnedConcertBooking));
			responseEntity = new ResponseEntity<ConcertBooking>(returnedConcertBooking,HttpStatus.OK);
            System.out.println(returnedConcertBooking.getConcertId());
		}

		catch(Exception exception) {
			System.out.println("Exception has occured");
			exception.printStackTrace();
			String errorMessage = environment.getProperty(exception.getMessage());
			ConcertBooking cb = new ConcertBooking();
			environment = ContextFactory.getContext().getEnvironment();
			String message = environment.getProperty(exception.getMessage());
            cb.setMessage(errorMessage);
			responseEntity = new ResponseEntity<ConcertBooking>(cb,HttpStatus.BAD_REQUEST);

		}

		return responseEntity;
	}

	private String getBookingSuccessMessage(ConcertBooking concertBooking) {
		Environment environment = ContextFactory.getContext().getEnvironment();
		String message = environment.getProperty("CONCERTAPI.BOOKING_SUCCESS1");
		message += concertBooking.getBookingId();
		message += environment.getProperty("CONCERTAPI.BOOKING_SUCCESS2");
		message += concertBooking.getTotalAmount();
		return message;

	}

}
