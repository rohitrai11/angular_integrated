package com.infy.model;

import java.util.Calendar;

public class ConcertBooking {
	
	private String concertGenre;
	private Calendar dateOfConcert;
	private String location;
	private String concertId;
	private Integer noOfTicket;
	private Long contactNo;
	private String message;
	
	private Integer bookingId;
	private String band;
	private String bookingStatus;
	private Double amount;
	private Double totalAmount;
	
	
	public Integer getBookingId() {
		return bookingId;
	}
	public void setBookingId(Integer bookingId) {
		this.bookingId = bookingId;
	}
	public String getConcertId() {
		return concertId;
	}
	public void setConcertId(String concertId) {
		this.concertId = concertId;
	}
	public Calendar getDateOfConcert() {
		return dateOfConcert;
	}
	public void setDateOfConcert(Calendar dateOfConcert) {
		this.dateOfConcert = dateOfConcert;
	}
	public Integer getNoOfTicket() {
		return noOfTicket;
	}
	public void setNoOfTicket(Integer noOfTicket) {
		this.noOfTicket = noOfTicket;
	}
	public Long getContactNo() {
		return contactNo;
	}
	public void setContactNo(Long contactNo) {
		this.contactNo = contactNo;
	}
	public String getBookingStatus() {
		return bookingStatus;
	}
	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}
	public String getConcertGenre() {
		return concertGenre;
	}
	public void setConcertGenre(String concertGenre) {
		this.concertGenre = concertGenre;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public Double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getBand() {
		return band;
	}
	public void setBand(String band) {
		this.band = band;
	}
	

}
