package com.infy.dao;

import com.infy.model.ConcertBooking;



public interface ConcertsInTownDAO {
	
	public ConcertBooking bookConcert(ConcertBooking concertBooking) throws Exception;
	
	String getAmountAndConcertIdOfConcertByGenreAndLocationAndDate(ConcertBooking concertBooking) throws Exception;

}
