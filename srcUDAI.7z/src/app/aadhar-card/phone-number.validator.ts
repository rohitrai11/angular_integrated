import { AbstractControl } from "@angular/forms";

export class PhoneNumberValidator {
    static noRepeat(control: AbstractControl){
        let num:string = control.value;
        let count = 0;
        let check = num[0];
        for(let i of num){
            if(i == check){
                count += 1;
            }
        }
        if(count == 10){
            return {
                noRepeat:true
            }
        }else{
            return null;
        }
    }
}