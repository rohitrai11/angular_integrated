import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup,Validators } from '@angular/forms';
import { AadharCardService } from './aadhar-card.service';
import { PhoneNumberValidator } from './phone-number.validator';
import { AadharCard } from './aadhar-card';

@Component({
  selector: 'app-aadhar-card',
  templateUrl: './aadhar-card.component.html',
  styleUrls: ['./aadhar-card.component.css']
})
export class AadharCardComponent implements OnInit {
  

  constructor(private formBuilder:FormBuilder, private aadharCardService : AadharCardService) { }

  successMessage:string;
  errorMessage:string;
  myAadhar : AadharCard;
  getAadharForm:FormGroup;
  updatePhoneNumberForm:FormGroup;


  ngOnInit() {
    this.getAadharForm = this.formBuilder.group({
      aadharNumber:["",[Validators.required,Validators.pattern("[0-9]{12}")]]
    })

    this.updatePhoneNumberForm = this.formBuilder.group({
      aadharNumber:["",[Validators.required]],
      phoneNumber:["",[Validators.required,Validators.pattern("[0-9]{10}"),PhoneNumberValidator.noRepeat]]
    })
  }

  getAadhar() {
    this.successMessage = null;
    this.errorMessage = null;
    this.myAadhar = null;
    this.aadharCardService.getAadhar(this.getAadharForm.value)
    .then(res=>this.setValues(res))
    .catch(res=>this.errorMessage=res.errorMessage)
  }
  updatePhoneNumber(){
    this.successMessage = null;
    this.errorMessage = null;
    this.aadharCardService.updatePhoneNumber(this.updatePhoneNumberForm.value)
    .then(res=>this.successMessage=res.message)
    .catch(res=>this.errorMessage=res.errorMessage)
  }
  setValues(res){
    this.myAadhar = res;
    this.updatePhoneNumberForm.setValue({aadharNumber:this.myAadhar.aadharNumber,phoneNumber:this.myAadhar.phoneNumber})
  }
}
