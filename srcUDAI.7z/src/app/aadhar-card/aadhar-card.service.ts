import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { AadharCard } from './aadhar-card';
import { Headers } from '@angular/http';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class AadharCardService {

  constructor(private http:Http) { }
  private headers = new Headers({'Content-Type':'application/json'});
  getAadhar(data) : Promise<AadharCard> {
    const url = "http://localhost:3333/UDAI_BackEnd/AadharAPI/getAadhar";
    return this.http.post(url, JSON.stringify(data), {headers:this.headers})
    .toPromise()
    .then(res=>res.json())
    .catch(this.errorHandler);
  }

  updatePhoneNumber(data): Promise<AadharCard> {
    const url = "http://localhost:3333/UDAI_BackEnd/AadharAPI/updatePhoneNumber";
    return this.http.post(url,JSON.stringify(data), {headers:this.headers})
    .toPromise()
    .then(res=>res.json())
    .catch(this.errorHandler)
  }
  errorHandler(error){
    return Promise.reject(error.json())
  }

}
