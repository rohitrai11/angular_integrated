import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Headers } from '@angular/http';
@Injectable()
export class BookConcertService {
  private headers = new Headers({'Content-Type': 'application/json'} );
  constructor(private http: Http) { }

  book(data) :Promise<any>{
    const url = 'http://localhost:8765/ConcertsInTownWS_To_Trainee/Concert/booking'; //Line 2
    return this.http.post(url, JSON.stringify(data), {headers: this.headers}) //Line 3
    .toPromise()
    .then(
      
    (res) =>res.json()
    ).catch(this.errorHandler);
  }
  private errorHandler(error:any):Promise<any> {
    console.error("Error occured",error);    
    return Promise.reject(error.json() || error);
    }

}  /* istanbul ignore next */

