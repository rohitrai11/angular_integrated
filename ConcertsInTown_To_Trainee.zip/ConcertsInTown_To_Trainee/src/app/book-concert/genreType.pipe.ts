import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'genreType'})
export class SuccessMessagePipe implements PipeTransform {
  transform(value: string): string {
     if(value=="BM"){
       return "Black Metal"
     }
     else if(value=="MM"){
       return "Metal";
     }
     else if(value=="HR"){
       return "Hard Metal"
     }
     else if(value=="BB"){
      return "Blues"
    }
    else if(value=="SU"){
      return "Sufi"
    }
     else{
    return null;
     }
  }

}