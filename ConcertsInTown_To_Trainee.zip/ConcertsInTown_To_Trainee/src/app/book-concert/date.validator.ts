import { AbstractControl } from "@angular/forms";

export class DateValidator {
    static checkDate(date: AbstractControl) {
        let rdate:Date=new Date(date.value)

        alert(typeof(rdate))
        
       alert("hi"+rdate.getFullYear())
        let today=new Date();
        if(rdate>today){
            return null;
        }
        else{
            return {checkDate:true}
        }

    }


}