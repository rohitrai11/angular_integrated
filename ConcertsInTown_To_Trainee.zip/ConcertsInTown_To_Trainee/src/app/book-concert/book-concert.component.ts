import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { BookConcertService } from './book-concert.service';
import { DateValidator } from './date.validator';

@Component({
  selector: 'app-book-concert',
  templateUrl: './book-concert.component.html',
  styleUrls: ['./book-concert.component.css']
})
export class BookConcertComponent implements OnInit {
  successMessage:string;
  errorMessage:string;
  genreTypeList:string[]=["BM","MM","HR","BB","SU"]
  bookingForm:FormGroup;
  constructor(private formBuilder:FormBuilder,private concertService:BookConcertService) { }

  book() {  
    this.successMessage=null;
    this.errorMessage=null;
    alert(this.bookingForm.value.concertGenre)
    this.concertService.book(this.bookingForm.value).then(response=>this.successMessage=response.message).catch(response=>this.errorMessage=response.message)  
  }

  ngOnInit() {   
    this.bookingForm=this.formBuilder.group({concertGenre:["",[Validators.required]],noOfTicket:["",[Validators.required]],
    location:["",Validators.required],dateOfConcert:["",[Validators.required,DateValidator.checkDate]]})  
  }

}   
