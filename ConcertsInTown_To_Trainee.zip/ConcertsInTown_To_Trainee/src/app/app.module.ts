import { BookConcertService } from './book-concert/book-concert.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BookConcertComponent } from './book-concert/book-concert.component';
import { HttpModule } from "@angular/http";
import { SuccessMessagePipe } from "./book-concert/genreType.pipe";

@NgModule({
  declarations: [
    AppComponent,
    BookConcertComponent,
    SuccessMessagePipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpModule
  ],
  providers: [BookConcertService],
  bootstrap: [AppComponent]
})
export class AppModule { }
