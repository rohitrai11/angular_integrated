import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BookConcertComponent } from './book-concert/book-concert.component';

const routes: Routes = [
  { path:'book', component: BookConcertComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
