package com.infy.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;


@Entity
@Table(name = "FlightsBooking")
@GenericGenerator(name="pkgen",strategy="sequence")
public class FlightsBookingEntity {
	
	
	@Id
	@GeneratedValue(generator ="pkgen" )
	private Integer bookingId;
	private String passengerName;
	private Integer bookingCost;
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="flightId")
	private FlightsEntity flightsEntity;
	
	
	public FlightsEntity getFlightsEntity() {
		return flightsEntity;
	}
	public void setFlightsEntity(FlightsEntity flightsEntity) {
		this.flightsEntity = flightsEntity;
	}
	public Integer getBookingId() {
		return bookingId;
	}
	public void setBookingId(Integer bookingId) {
		this.bookingId = bookingId;
	}
	public String getPassengerName() {
		return passengerName;
	}
	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}
	public Integer getBookingCost() {
		return bookingCost;
	}
	public void setBookingCost(Integer bookingCost) {
		this.bookingCost = bookingCost;
	}
	
}
