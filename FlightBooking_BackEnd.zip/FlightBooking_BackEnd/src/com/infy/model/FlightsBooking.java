package com.infy.model;

public class FlightsBooking {
	
	private Integer bookingId;
	private String passengerName;
	private Integer bookingCost;
	private Integer noOfTickets;
	private String message;
	private Flights flights;
	
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Integer getBookingId() {
		return bookingId;
	}
	public void setBookingId(Integer bookingId) {
		this.bookingId = bookingId;
	}
	public String getPassengerName() {
		return passengerName;
	}
	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}
	public Integer getBookingCost() {
		return bookingCost;
	}
	public void setBookingCost(Integer bookingCost) {
		this.bookingCost = bookingCost;
	}
	public Flights getFlights() {
		return flights;
	}
	public void setFlights(Flights flights) {
		this.flights = flights;
	}
	
	public Integer getNoOfTickets() {
		return noOfTickets;
	}
	public void setNoOfTickets(Integer noOfTickets) {
		this.noOfTickets = noOfTickets;
	}
	
}
