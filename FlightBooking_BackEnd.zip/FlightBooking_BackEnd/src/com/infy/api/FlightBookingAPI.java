package com.infy.api;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.model.FlightsBooking;
import com.infy.service.FlightBookingService;
import com.infy.service.FlightBookingServiceImpl;
import com.infy.utility.ContextFactory;



@RestController
@CrossOrigin
@RequestMapping(value="flight")
public class FlightBookingAPI {
	
	private FlightBookingService service;
	@RequestMapping(method=RequestMethod.POST, value="booking")
	public ResponseEntity<FlightsBooking> addBooking(@RequestBody FlightsBooking flightBooking){
		System.out.println("Inside API"+flightBooking.getFlights().getFlightId());
		Environment environment= ContextFactory.getContext().getEnvironment();
		ResponseEntity<FlightsBooking> responseEntity=null;
		try{
			service=(FlightBookingService) ContextFactory.getContext().getBean(FlightBookingServiceImpl.class);
		
		    Integer bookingId=service.bookFlight(flightBooking);
		    FlightsBooking fb1=new FlightsBooking();
		    fb1.setBookingId(bookingId);
		    responseEntity = new ResponseEntity<FlightsBooking>(fb1,HttpStatus.OK);
		    System.out.println(responseEntity.getBody().getBookingId());
		}catch(Exception e){
			String errorMessage = environment.getProperty(e.getMessage());
			FlightsBooking fb=new FlightsBooking();
			//fb.setMessage(errorMessage);
			fb.setMessage(errorMessage);
			responseEntity = new ResponseEntity<FlightsBooking>(fb,HttpStatus.OK);
		}
		return responseEntity;

	}


}
