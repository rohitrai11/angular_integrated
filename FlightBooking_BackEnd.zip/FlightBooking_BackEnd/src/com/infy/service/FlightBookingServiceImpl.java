package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.FlightBookingDAO;
import com.infy.model.Flights;
import com.infy.model.FlightsBooking;


@Service("flightBookingService")
@Transactional(readOnly = true)
public class FlightBookingServiceImpl implements FlightBookingService {

	
	@Autowired
	private FlightBookingDAO dao;

	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Integer bookFlight(FlightsBooking flightBooking) throws Exception {
		
		Integer bookingId = null;
		
		//Validator.validateFlightId(flightBooking.getFlights().getFlightId());
		System.out.println("Service1"+flightBooking.getFlights().getFlightId());
		Flights flights = dao.checkAvailability(flightBooking.getFlights().getFlightId());
        System.out.println("Service2"+flights.getFlightId());
		
		if(flights == null|| flights.getStatus()=="Cancelled")
			throw new Exception("Service.FLIGHT_UNAVAILABLE");
		
		if(flights.getAvailableSeats()<flightBooking.getNoOfTickets()){
			throw new Exception("Service.SEATS_UNAVAILABLE");
			}
		else{
			flightBooking.setBookingCost(flights.getFare()*flightBooking.getNoOfTickets());
		}
		flightBooking.setFlights(flights);		
		bookingId = dao.bookFlight(flightBooking);
		
		
		return bookingId;
	}


	
}


