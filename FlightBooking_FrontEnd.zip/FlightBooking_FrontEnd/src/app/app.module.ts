import { BookFlightService } from './book-flight/book-flight.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BookFlightComponent } from './book-flight/book-flight.component';
import { HttpModule } from "@angular/http";
import { SuccessMessagePipe } from "./book-flight/success-message.pipe";

@NgModule({
  declarations: [
    AppComponent,
    BookFlightComponent,
    SuccessMessagePipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpModule
  ],
  providers: [BookFlightService],
  bootstrap: [AppComponent]
})
export class AppModule { }
