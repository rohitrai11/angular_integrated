import { AbstractControl } from "@angular/forms";

export class PassengerNameValidator {
    static checkName(name: AbstractControl) {
        let flag=true;
        let flag2=true;
        let value=name.value as string;
        
        for(let i=0;i<value.split("").length;i++){
            //alert(value.charCodeAt(i))
           if( value.charCodeAt(i)<65 || value.charCodeAt(i)>122){
            if(value.charCodeAt(i)!=32) {
                  flag=false;
            }
            }

        }
        let arr=value.split(" ");
        for(let i=0;i<arr.length;i++){
            if(arr[i].length<2 && arr[i].charCodeAt(0)!=32){
                flag2=false;
            }
        }

        if( flag && flag2){
            return null;
        }
        else{
            return {checkName:true}
        }
    }

}