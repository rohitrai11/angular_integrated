import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class BookConcertService {

  constructor(private http: Http) { }

  book(data) :Promise<any>{
    return null;
  }
  private errorHandler(error:any):Promise<any> {
    console.error("Error occured",error);    
    return Promise.reject(error.json() || error);
    }

}  /* istanbul ignore next */

