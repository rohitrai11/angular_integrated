import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { BookConcertService } from './book-concert.service';
import { DateValidator } from './date.validator';

@Component({
  selector: 'app-book-concert',
  templateUrl: './book-concert.component.html',
  styleUrls: ['./book-concert.component.css']
})
export class BookConcertComponent implements OnInit {

  constructor() { }

  book() {    
  }

  ngOnInit() {     
  }

}   
