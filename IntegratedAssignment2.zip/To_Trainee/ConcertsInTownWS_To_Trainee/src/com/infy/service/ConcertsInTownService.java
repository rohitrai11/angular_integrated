package com.infy.service;



import com.infy.model.ConcertBooking;



public interface ConcertsInTownService {
	
	public ConcertBooking bookConcert(ConcertBooking concertBooking) throws Exception;

}
