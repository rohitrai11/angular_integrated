package com.infy.dao;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.ConcertBookingEntity;
import com.infy.entity.ConcertEntity;
import com.infy.model.ConcertBooking;

@Repository("dao")
public class ConcertsInTownDAOImpl implements ConcertsInTownDAO {

	@Autowired
	SessionFactory sessionFactory;

	@Override
	public ConcertBooking bookConcert(ConcertBooking concertBooking) throws Exception {

		Session session = sessionFactory.getCurrentSession();

		ConcertBookingEntity concertBookingEntity = new ConcertBookingEntity();
		concertBookingEntity.setConcertId(concertBooking.getConcertId());
		concertBookingEntity.setDateOfConcert(concertBooking.getDateOfConcert());
		concertBookingEntity.setNoOfTickets(concertBooking.getNoOfTicket());
		concertBookingEntity.setContactNo(concertBooking.getContactNo());
		concertBookingEntity.setAmount(concertBooking.getTotalAmount());
		Integer id = (Integer) session.save(concertBookingEntity);

		concertBooking.setBookingId(id);

		return concertBooking;

	}

	@Override
	public String getAmountAndConcertIdOfConcertByGenreAndLocationAndDate(ConcertBooking concertBooking) throws Exception {
		
		Session session = sessionFactory.getCurrentSession();
		
		CriteriaBuilder builder = session.getCriteriaBuilder();
		
		CriteriaQuery<Object[]> criteriaQuery = builder.createQuery(Object[].class);
		
		Root<ConcertEntity> root = criteriaQuery.from(ConcertEntity.class);
		
		criteriaQuery.where(
				builder.and(
						builder.equal(root.get("concertGenre"), concertBooking.getConcertGenre()),
						builder.equal(root.get("location"), concertBooking.getLocation()), 
						builder.equal(root.get("dateOfConcert"), concertBooking.getDateOfConcert())
				));
		criteriaQuery.multiselect(root.get("amount"), root.get("concertId"));
		
		Query<Object[]> query = session.createQuery(criteriaQuery);
		
		List<Object[]> list = query.getResultList();
		
		if(list!=null && !list.isEmpty()) {
			return list.get(0)[0]+"-"+list.get(0)[1];
		}else {
			return null;
		}
		
	}
}
