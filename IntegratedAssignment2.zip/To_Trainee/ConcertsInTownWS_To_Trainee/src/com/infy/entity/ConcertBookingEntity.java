package com.infy.entity;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;


@Entity
@Table(name = "Concert_Booking_Details")
@GenericGenerator(name="pkgen", strategy="increment")
public class ConcertBookingEntity {
	
	@Id
	@GeneratedValue(generator="pkgen")
	private Integer bookingId;
	
	private String concertId;
	
	@Temporal(TemporalType.DATE)
	private Calendar dateOfConcert;
	
	private Integer noOfTickets;
	
	private Long contactNo;
	
	@Column(insertable = false)
	private String bookingStatus;
	
	@Column(name="totalAmount")
	private Double amount;
	
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public Integer getBookingId() {
		return bookingId;
	}
	public void setBookingId(Integer bookingId) {
		this.bookingId = bookingId;
	}
	public String getConcertId() {
		return concertId;
	}
	public void setConcertId(String concertId) {
		this.concertId = concertId;
	}
	public Calendar getDateOfConcert() {
		return dateOfConcert;
	}
	public void setDateOfConcert(Calendar dateOfConcert) {
		this.dateOfConcert = dateOfConcert;
	}
	public Integer getNoOfTickets() {
		return noOfTickets;
	}
	public void setNoOfTickets(Integer noOfTickets) {
		this.noOfTickets = noOfTickets;
	}
	public Long getContactNo() {
		return contactNo;
	}
	public void setContactNo(Long contactNo) {
		this.contactNo = contactNo;
	}
	public String getBookingStatus() {
		return bookingStatus;
	}
	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}
	
	

}
