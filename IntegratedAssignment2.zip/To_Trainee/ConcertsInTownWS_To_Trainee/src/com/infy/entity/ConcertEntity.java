package com.infy.entity;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;



@Entity
@Table(name="Concert_Details")
public class ConcertEntity {
	
	@Id
	private String concertId;
	private String concertGenre ;
	private String location;
	private Double amount;
	@Column(name="artist_band")
	private String band;
	@Temporal(TemporalType.DATE)
	private Calendar dateOfConcert;
	public String getBand() {
		return band;
	}
	public void setBand(String band) {
		this.band = band;
	}
	public Calendar getDateOfConcert() {
		return dateOfConcert;
	}
	public void setDateOfConcert(Calendar dateOfConcert) {
		this.dateOfConcert = dateOfConcert;
	}
	public String getConcertId() {
		return concertId;
	}
	public void setConcertId(String concertId) {
		this.concertId = concertId;
	}
	public String getConcertGenre() {
		return concertGenre;
	}
	public void setConcertGenre(String concertGenre) {
		this.concertGenre = concertGenre;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	
	

}
