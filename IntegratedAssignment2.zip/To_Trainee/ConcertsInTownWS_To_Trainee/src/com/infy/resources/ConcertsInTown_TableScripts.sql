drop sequence hibernate_sequence;
create sequence hibernate_sequence start with 6660 increment by 1;


Drop table Concert_Details cascade constraints;
CREATE TABLE Concert_Details(
    concertId   VARCHAR2(5),
    concertGenre VARCHAR2(2) NOT NULL,
    location VARCHAR2(25) NOT NULL,
    amount NUMBER(8,2) NOT NULL,
    artist_band VARCHAR2(50) NOT NULL,
    dateOfConcert DATE NOT NULL,
    CONSTRAINT pk_Con_Details_tId PRIMARY KEY(concertId),
    CONSTRAINT chk_Con_Details_cost CHECK (amount > 0.0)
);


Drop table Concert_Booking_Details cascade constraints;
CREATE TABLE Concert_Booking_Details(
  	bookingId NUMBER(10), 
  	concertId VARCHAR2(5) NOT NULL, 
  	dateOfConcert DATE,
  	noOfTickets NUMBER(2) NOT NULL,
  	contactNo NUMBER(10),
  	totalAmount NUMBER NOT NULL,
  	bookingStatus VARCHAR2(2) DEFAULT 'PN' NOT NULL,
    CONSTRAINT pk_Book_Details_Id PRIMARY KEY(bookingId),
    CONSTRAINT fk_Book_Details_tId FOREIGN KEY(concertId) REFERENCES Concert_Details(concertId) ON DELETE CASCADE,
    CONSTRAINT chk_Book_Details_noOfTickets CHECK (noOfTickets > 0 and noOfTickets <= 12),
    CONSTRAINT chk_Book_details_status CHECK (bookingStatus in ('PN','CO')) 
);
--PN - pending CO - confirmed




INSERT INTO Concert_Details VALUES ('C666', 'BM','Delhi',1000.00,'TOXOID',TRUNC(SYSDATE)+1);
INSERT INTO Concert_Details VALUES ('C102', 'BM','Delhi',1500.00,'VidhvansaK',TRUNC(SYSDATE)+3);
INSERT INTO Concert_Details VALUES ('C103', 'MM','Delhi',2500.00,'Metallica',TRUNC(SYSDATE)+79);
INSERT INTO Concert_Details VALUES ('C104', 'SU','Mumbai',900.00,'Nusrat Fateh Ali Khan',TRUNC(SYSDATE)+10);
INSERT INTO Concert_Details VALUES ('C105', 'HR','Mumbai',1200.00,'Deep Purple',TRUNC(SYSDATE)+11);
INSERT INTO Concert_Details VALUES ('C106', 'MM','Mumbai',2200.00,'Megadeth',TRUNC(SYSDATE)+15);
INSERT INTO Concert_Details VALUES ('C107', 'HR','Pune',700.00,'TOXOID',TRUNC(SYSDATE)+22);
INSERT INTO Concert_Details VALUES ('C108', 'HR','Hyderabad',1100.00,'TOXOID',TRUNC(SYSDATE)+57);
INSERT INTO Concert_Details VALUES ('C109', 'BB','Pune',2600.00,'Soul Inclination',TRUNC(SYSDATE)+100);
INSERT INTO Concert_Details VALUES ('C110', 'MM','Bangalore',2600.00,'TOXOID',TRUNC(SYSDATE)+45);
INSERT INTO Concert_Details VALUES ('C111', 'BM','Bangalore',2600.00,'Burzum',TRUNC(SYSDATE)+66);
INSERT INTO Concert_Details VALUES ('C112', 'BB','Bangalore',2600.00,'Dreamscapade',TRUNC(SYSDATE)+3);
INSERT INTO Concert_Details VALUES ('C113', 'BM','Hyderabad',2600.00,'VidhvansaK',TRUNC(SYSDATE)+5);




INSERT INTO Concert_Booking_Details VALUES (1001,'C666',TRUNC(SYSDATE)+1, 6, 8095487654,6000,'PN');
INSERT INTO Concert_Booking_Details VALUES (1002,'C102',TRUNC(SYSDATE)+3, 8, 9968456711,12000,'PN');

Commit;

SELECT * from Concert_Details where concertId = 'C666';