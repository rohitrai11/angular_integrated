package com.infy.api;

import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;

import com.infy.model.ConcertBooking;
import com.infy.utility.ContextFactory;


public class ConcertAPI {

	public ResponseEntity<ConcertBooking> bookConcert(ConcertBooking concertBooking) throws Exception {
		return null;
	}

	private String getBookingSuccessMessage(ConcertBooking concertBooking) {
		Environment environment = ContextFactory.getContext().getEnvironment();
		String message = environment.getProperty("CONCERTAPI.BOOKING_SUCCESS1");
		message += concertBooking.getBookingId();
		message += environment.getProperty("CONCERTAPI.BOOKING_SUCCESS2");
		message += concertBooking.getTotalAmount();
		return message;

	}

}
