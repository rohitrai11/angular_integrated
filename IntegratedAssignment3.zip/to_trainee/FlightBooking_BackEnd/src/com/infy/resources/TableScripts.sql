DROP TABLE FlightsBooking;

DROP TABLE Flights;

DROP SEQUENCE HIBERNATE_SEQUENCE;

CREATE SEQUENCE hibernate_sequence START WITH 2011 INCREMENT BY 1;


create table Flights(
flightId number(4) PRIMARY KEY,
aircraftName varchar2(30) not null,
fare number not null,
availableSeats number not null,
status varchar2(10) not null
);

insert into Flights values(1001,'Delta Airlines',600,3,'Running');
insert into Flights values(1002,'JetBlue',745,2,'Running');
insert into Flights values(1003,'United Airlines',865,0,'Running');
insert into Flights values(1004,'Virgin America',580,0,'Cancelled');
insert into Flights values(1005,'Allegiant Air',650,7,'Running');
insert into Flights values(1006,'Hawaiian Airlines',800,4,'Running');


create table FlightsBooking(
bookingId number PRIMARY KEY,
passengerName varchar2(10) not null,
bookingCost number not null,
flightId number(4)  references Flights(flightId) 
); 

insert into FlightsBooking values(2001,'Markel',1200,1001);
insert into FlightsBooking values(2002,'Louis',1850,1001);
insert into FlightsBooking values(2003,'Rita',950,1004);
insert into FlightsBooking values(2004,'Lizzy',1020,1005);
insert into FlightsBooking values(2005,'Ronaldo',1200,1005);
insert into FlightsBooking values(2006,'Isabella',895,1005);
insert into FlightsBooking values(2007,'Shandar',980,1005);
insert into FlightsBooking values(2008,'Julia',1500,1002);
insert into FlightsBooking values(2009,'Eric',1040,1002);
insert into FlightsBooking values(2010,'Adrian',900,1002);



select * from FlightsBooking;

select * from Flights;


