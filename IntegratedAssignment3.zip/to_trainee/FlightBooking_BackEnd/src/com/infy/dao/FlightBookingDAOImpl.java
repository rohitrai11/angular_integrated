package com.infy.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.FlightsBookingEntity;
import com.infy.entity.FlightsEntity;
import com.infy.model.Flights;
import com.infy.model.FlightsBooking;


@Repository("dao")
public class FlightBookingDAOImpl implements FlightBookingDAO {

	@Autowired
	SessionFactory sessionFactory;

	public Flights checkAvailability(Integer flightId) throws Exception {
		Session session = null;

		session = sessionFactory.getCurrentSession();
		
		Flights flights = null;

		FlightsEntity flightsEntity = session.get(FlightsEntity.class,flightId);

		if (flightsEntity!= null && flightsEntity.getStatus().equals("Running")) {

			flights = new Flights();
			flights.setAircraftName(flightsEntity.getAircraftName());
			flights.setAvailableSeats(flightsEntity.getAvailableSeats());
			flights.setFare(flightsEntity.getFare());
			flights.setFlightId(flightsEntity.getFlightId());
			flights.setStatus(flightsEntity.getStatus());
		
		}    
		
		return flights;
	}

	
	public Integer bookFlight(FlightsBooking flightBooking) throws Exception {
		
		
		
		Session session = sessionFactory.getCurrentSession();
		
		FlightsBookingEntity flightsBookingEntity = new FlightsBookingEntity();
		FlightsEntity flightsEntity = new FlightsEntity();


		flightsBookingEntity.setBookingCost(flightBooking.getBookingCost());
		flightsBookingEntity.setPassengerName(flightBooking.getPassengerName());
		
		flightsEntity.setFlightId(flightBooking.getFlights().getFlightId());
		
		// persisting the flightsBookingEntity object
		session.persist(flightsBookingEntity);


		return flightsBookingEntity.getBookingId();
	}

	
}
