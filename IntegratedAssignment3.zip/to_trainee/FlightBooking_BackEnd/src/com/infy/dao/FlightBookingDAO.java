package com.infy.dao;

import com.infy.model.Flights;
import com.infy.model.FlightsBooking;




public interface FlightBookingDAO {
	
	public Flights checkAvailability(Integer flightId) throws Exception;
	public Integer bookFlight(FlightsBooking flightBooking) throws Exception;
	


}
