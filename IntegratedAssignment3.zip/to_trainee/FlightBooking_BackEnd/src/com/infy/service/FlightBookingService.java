package com.infy.service;

import com.infy.model.FlightsBooking;




public interface FlightBookingService {
	
	public Integer bookFlight(FlightsBooking flightBooking) throws Exception;
	
}
