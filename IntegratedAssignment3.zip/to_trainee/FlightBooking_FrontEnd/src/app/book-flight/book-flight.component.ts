import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { BookFlightService } from './book-flight.service';
import { PassengerNameValidator } from './passenger-name.validator';

@Component({
  selector: 'app-book-flight',
  templateUrl: './book-flight.component.html',
  styleUrls: ['./book-flight.component.css']
})
export class BookFlightComponent implements OnInit {
  
  constructor() { }

  ngOnInit() {
  }

  book() {
  }

}