import { AbstractControl } from "@angular/forms";

export class PassengerNameValidator {
    static checkName(name: AbstractControl) {
        return null;
    }

}