import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class BookFlightService {

  constructor() { }

  book(data):Promise<any> {
    return null;
  }

  handleError(error){
    return Promise.reject(error.json() || error);
  }

}   