package com.infy.api;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.model.AadharCard;
import com.infy.service.UDAIService;
import com.infy.service.UDAIServiceImpl;
import com.infy.utility.ContextFactory;

@RestController
@CrossOrigin
@RequestMapping(value="AadharAPI")
public class AadharAPI {
	private Environment environment;
	private UDAIService service;
	@RequestMapping(method=RequestMethod.POST, value="getAadhar")
	public ResponseEntity<AadharCard> getAadhar(@RequestBody AadharCard aadhar){
		System.out.println("HIIII"+aadhar.getAadharNumber());
		environment= ContextFactory.getContext().getEnvironment();
		ResponseEntity<AadharCard> responseEntity=null;
		AadharCard aadharCard=new AadharCard();
		service=(UDAIService)ContextFactory.getContext().getBean(UDAIServiceImpl.class);
try {
			System.out.println(environment.toString());
			aadharCard=service.getAadhar(aadhar.getAadharNumber());
			responseEntity = new ResponseEntity<>(aadharCard,HttpStatus.OK);

		}


		catch(Exception exception) {
			System.out.println(exception);
			String errorMessage = environment.getProperty(exception.getMessage());
			AadharCard ac = new AadharCard();
			ac.setMessage(errorMessage);			
					
			responseEntity = new ResponseEntity<>(ac,HttpStatus.BAD_REQUEST);
			

		}

		return responseEntity;
	}
	@RequestMapping(method=RequestMethod.POST, value="updatePhoneNumber")
	public ResponseEntity<AadharCard> updatePhoneNumber(@RequestBody AadharCard aadhar){
		System.out.println("update in java"+aadhar.getAadharNumber());
		Environment environment= ContextFactory.getContext().getEnvironment();
		ResponseEntity<AadharCard> responseEntity=null;
		AadharCard aadharCard=new AadharCard();
		service=(UDAIService)ContextFactory.getContext().getBean(UDAIServiceImpl.class);
try {
			
			aadharCard=service.updatePhoneNumber(aadhar);
			aadharCard.setMessage(environment.getProperty("AadharAPI.SUCCESSFULL"));
			responseEntity = new ResponseEntity<>(aadharCard,HttpStatus.OK);
            System.out.println("Succces message "+aadharCard.getMessage());
		}


		catch(Exception exception) {
			System.out.println(exception);
			String errorMessage = environment.getProperty(exception.getMessage());
			AadharCard ac = new AadharCard();
			ac.setMessage(errorMessage);			
					
			responseEntity = new ResponseEntity<>(ac,HttpStatus.BAD_REQUEST);
			

		}
		return responseEntity;
	}


}
