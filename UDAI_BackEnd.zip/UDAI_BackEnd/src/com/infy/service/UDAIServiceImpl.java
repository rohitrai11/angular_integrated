package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.UDAIDAO;
import com.infy.model.AadharCard;

@Service("udaiService")
@Transactional(readOnly = true)
public class UDAIServiceImpl implements UDAIService {

	
	@Autowired
	private UDAIDAO dao;

	
	@Transactional(readOnly = true)
	public AadharCard getAadhar(String aadharNumber) throws Exception {
		
		AadharCard aadharCard = dao.getAadhar(aadharNumber);
		
		if(aadharCard == null) {
			throw new Exception("Service.INVALID_AADHAR_NUMBER");
		}
		
		return aadharCard;
	}


	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public AadharCard updatePhoneNumber(AadharCard aadhar) throws Exception {
		AadharCard aadharCard = dao.updatePhoneNumber(aadhar);
		if(aadharCard == null) {
			throw new Exception("Service.INVALID_AADHAR_NUMBER");
		}
		return aadharCard;
	}


	
}


