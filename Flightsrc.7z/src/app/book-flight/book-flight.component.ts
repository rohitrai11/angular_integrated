import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { BookFlightService } from './book-flight.service';
import { PassengerNameValidator } from './passenger-name.validator';

@Component({
  selector: 'app-book-flight',
  templateUrl: './book-flight.component.html',
  styleUrls: ['./book-flight.component.css']
})
export class BookFlightComponent implements OnInit {
  successMessage:string;
  errorMessage:string;
  bookingId:any;
  bookingForm:FormGroup;
  flights:FormGroup;
  
  
  constructor(private formBuilder:FormBuilder,private bookingService:BookFlightService) { }

  ngOnInit() {
   this.flights=this.formBuilder.group(
     {
       flightId:["",[Validators.required,Validators.min(1000),Validators.max(9999)]]
     }
   );
   this.bookingForm=this.formBuilder.group(
     {
        passengerName:["",[Validators.required,PassengerNameValidator.checkName]],
        noOfTickets:["",[Validators.required]],
        flights:this.flights
      }
   );
  }

  book() {
    alert(JSON.stringify(this.bookingForm.value))
    this.bookingService.book(this.bookingForm).
    then(response=>{this.bookingId=response.bookingId;
                   alert("Hello "+this.successMessage)
                   
                   
                    
    }).catch(response=>this.errorMessage=response.message);
  }

}