import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import {Headers} from '@angular/http'

@Injectable()
export class BookFlightService {
  private headers = new Headers({'Content-Type': 'application/json'} );
  constructor(private http:Http) { }

  book(data):Promise<any> {
    alert(data.value.passengerName)
    return this.http.post('http://localhost:8765/FlightBooking_BackEnd/flight/booking', JSON.stringify(data.value), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json() as any)    
  .catch(this.handleError);
  }

  handleError(error){
    return Promise.reject(error.json() || error);
  }

}   